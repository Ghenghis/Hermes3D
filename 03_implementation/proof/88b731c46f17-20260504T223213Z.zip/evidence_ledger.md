# Evidence Ledger

| claim | proof_type | bundle_path |
|---|---|---|
| readiness_notes | document | proof/TESTS_PROOF_READINESS.md |
| supporting_artifact | file | tests/e2e/artifacts/.last-run.json |
| ui_screenshot | screenshot | tests/e2e/artifacts/dashboard.steps-20-24-Phas-2b03b--and-chronological-activity-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/dashboard.steps-20-24-Phas-2b03b--and-chronological-activity-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/dashboard.steps-20-24-Phas-568c2-s-expose-stable-proof-hooks-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/dashboard.steps-20-24-Phas-568c2-s-expose-stable-proof-hooks-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/dashboard.steps-20-24-Phas-5f787-nder-CPU-RAM-and-GPU-labels-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/dashboard.steps-20-24-Phas-5f787-nder-CPU-RAM-and-GPU-labels-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/dashboard.steps-20-24-Phas-6a545-nd-adapter-provenance-chips-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/dashboard.steps-20-24-Phas-6a545-nd-adapter-provenance-chips-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/dashboard.steps-20-24-Phas-eab99--stages-and-active-progress-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/dashboard.steps-20-24-Phas-eab99--stages-and-active-progress-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/printer-control.step-34-Ph-087ad-hout-issuing-network-writes-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/printer-control.step-34-Ph-087ad-hout-issuing-network-writes-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/printer-control.step-34-Ph-5540c--and-all-five-safety-panels-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/printer-control.step-34-Ph-5540c--and-all-five-safety-panels-chromium-e2e/trace.zip |
| ui_screenshot | screenshot | tests/e2e/artifacts/printer-control.step-34-Ph-9dd3c-dapter-safety-wiring-exists-chromium-e2e/test-failed-1.png |
| supporting_artifact | file | tests/e2e/artifacts/printer-control.step-34-Ph-9dd3c-dapter-safety-wiring-exists-chromium-e2e/trace.zip |
| playwright_e2e_results | test_report | tests/e2e/results.json |
