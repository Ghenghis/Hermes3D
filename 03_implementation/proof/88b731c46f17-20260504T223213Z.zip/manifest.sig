{
  "algorithm": "HMAC-SHA256",
  "value": "c48bfc0c904f929043b7c02822e04bba2d72c1ad6efc5566464f2436bc573a3b"
}
